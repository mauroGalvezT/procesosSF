


	       <ul class="nav menu">

			<li ><a href="../Alumnos/tabla.php"><svg class="glyph stroked male user "><use xlink:href="#stroked-male-user"/></svg>Alumnos</a></li>

			<li><a href="../Colegiaturas/tabla.php"><svg class="glyph stroked line-graph"><use xlink:href="#stroked-line-graph"></use></svg>Colegiaturas</a></li>
			<!--li><a href="../panels.html"><svg class="glyph stroked app-window"><use xlink:href="../#stroked-app-window"></use></svg> Venta &amp;  de Libros</a></li-->

			<li role="presentation" class="divider"></li>

            <!--li><a href="../Ventas/venta.php"><svg class="glyph stroked app-window"><use xlink:href="../#stroked-app"></use></svg>Inventario</a></li-->
			</ul>
